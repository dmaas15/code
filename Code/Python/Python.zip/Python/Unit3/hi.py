print("Goodbye Cruel World!!!")
