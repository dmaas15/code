print('Beware of Monitor Lizard!!')
