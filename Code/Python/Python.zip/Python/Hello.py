print('Hello from a file')
